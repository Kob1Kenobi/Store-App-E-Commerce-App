package com.kodekenobi.store.Prevalent;

import com.kodekenobi.store.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;

    public static final String UserPhoneKey="UserPhone";
    public static final String UserPasswordKey="UserPassword";
}
