package com.kodekenobi.store;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.kodekenobi.store.R;

public class SplashActivity extends AppCompatActivity
{
    //Animation topA,bottomA;
    ImageView img;
    TextView s_title,title_txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        img = (ImageView) findViewById(R.id.splash_img);

//        topA = AnimationUtils.loadAnimation(this,R.anim.top_animation);
//        bottomA = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);
//
//        s_title = (TextView) findViewById(R.id.title);
//        title_txt = (TextView) findViewById(R.id.title_text);
//
//        img.setAnimation(topA);
//        s_title.setAnimation(bottomA);
//        title_txt.setAnimation(bottomA);
//        SystemClock.sleep(4000);

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(mainIntent);
                Toast.makeText(SplashActivity.this, "Welcome to the Store App", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
}
