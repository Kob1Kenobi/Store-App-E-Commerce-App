# Online-Shopping-App
A basic android application project on e-commerce shopping; using Android Studio and Firebase real time databas